#include <GLEW/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>

// GLM Mathematics
#include <glm/glm/glm.hpp>
#include <glm/glm/gtc/matrix_transform.hpp>
#include <glm/glm/gtc/type_ptr.hpp>

#include <Camera/camera.h>

#include <SOIL2/SOIL2.h>

using namespace std;

// camera
Camera gCamera(glm::vec3(0.0f, 0.0f, 5.0f));
bool viewProjection = true;


int width, height;
const double PI = 3.14159;
const float toRadians = PI / 180.0f;

//Input Function Prototypes
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void cursor_position_callback(GLFWwindow* window, double xpos, double ypos);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);

//Declare view matrix
glm::mat4 viewMatrix;

//Initialize  FOV
GLfloat fov = 45.f;


//Define Camera Attributes
glm::vec3 cameraPosition = glm::vec3(0.f, 3.f, 8.f);
glm::vec3 target = glm::vec3(0.f, 0.f, 0.f);
glm::vec3 cameraDirection = glm::normalize(cameraPosition - target);
glm::vec3 worldUp = glm::vec3(0.f, 1.f, 0.f);
glm::vec3 cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));
glm::vec3 cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight));
glm::vec3 cameraFront = glm::normalize(glm::vec3(0.f, 0.f, -1.f));

//Declares target prototype
glm::vec3 getTarget();

//Camera Transformation Prototype
void TransformCamera();

//Boolean for keys and mouse buttons
bool keys[1024], mouseButtons[3];

//Boolean to check camera transformation
bool isPanning = false, isOrbiting = false;

//Radius, Pitch and Yaw Variables
GLfloat radius = 3.f, rawYaw = 0.f, rawPitch = 0.f, degYaw, degPitch;


GLfloat deltaTime = 0.f, lastFrame = 0.f;
GLfloat lastX = 320, lastY = 240, xChange, yChange;

bool firstMouseMove = true;//Detect initial mouse movement


void initCamera();

//Light source position
glm::vec3 lightPosition(0.0f, 4.0f, 2.0f);


// Draw Primitive(s)
void draw()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 6;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);


}

// Create and Compile Shaders
static GLuint CompileShader(const string& source, GLuint shaderType)
{
	// Create Shader object
	GLuint shaderID = glCreateShader(shaderType);
	const char* src = source.c_str();

	// Attach source code to Shader object
	glShaderSource(shaderID, 1, &src, nullptr);

	// Compile Shader
	glCompileShader(shaderID);

	// Return ID of Compiled shader
	return shaderID;

}

// Create Program Object
static GLuint CreateShaderProgram(const string& vertexShader, const string& fragmentShader)
{
	// Compile vertex shader
	GLuint vertexShaderComp = CompileShader(vertexShader, GL_VERTEX_SHADER);

	// Compile fragment shader
	GLuint fragmentShaderComp = CompileShader(fragmentShader, GL_FRAGMENT_SHADER);

	// Create program object
	GLuint shaderProgram = glCreateProgram();

	// Attach vertex and fragment shaders to program object
	glAttachShader(shaderProgram, vertexShaderComp);
	glAttachShader(shaderProgram, fragmentShaderComp);

	// Link shaders to create executable
	glLinkProgram(shaderProgram);

	// Delete compiled vertex and fragment shaders
	glDeleteShader(vertexShaderComp);
	glDeleteShader(fragmentShaderComp);

	// Return Shader Program
	return shaderProgram;

}



int main(void)
{
	width = 640; height = 480;

	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(width, height, "ElliotCollins 3D Scene", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	//Set input callback functions
	glfwSetKeyCallback(window, key_callback);
	glfwSetCursorPosCallback(window, cursor_position_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetScrollCallback(window, scroll_callback);

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	if (glewInit() != GLEW_OK)
		cout << "Error!" << endl;

	//lamp positions (same vertices positions as object)
	GLfloat lampVertices[] = {
		-0.5, -0.5, 0.0, // index 0
		-0.5, 0.5, 0.0, // index 1
		0.5, -0.5, 0.0,  // index 2	
		0.5, 0.5, 0.0,  // index 3	
	};

	GLfloat vertices[] = {

		// Triangle 1
		-0.5, -0.5, 0.0, // index 0
		1.0, 0.0, 0.0, // red
		0.0, 0.0,// UV (bl)
		0.0f,0.0f,1.0f, // normal positive z

		-0.5, 0.5, 0.0, // index 1
		0.0, 1.0, 0.0, // green
		0.0, 1.0,// UV (tl)
		0.0f,0.0f,1.0f, // normal positive z

		0.5, -0.5, 0.0,  // index 2	
		0.0, 0.0, 1.0, // blue
		1.0, 0.0, // UV (br)
		0.0f,0.0f,1.0f, // normal positive z

		// Triangle 2	
		0.5, 0.5, 0.0,  // index 3	
		1.0, 0.0, 1.0, // purple
		1.0, 1.0, // UV (tr)
		0.0f,0.0f,1.0f // normal positive z
	};

	// Define element indices
	GLubyte indices[] = {
		0, 1, 2,
		1, 2, 3
	};

	//Plane positions
	glm::vec3 planePositions[] =
	{
		glm::vec3(0.0f, 0.0f, -0.5f),//front
		glm::vec3(0.0f, 0.0f, -1.5f),//back
		glm::vec3(0.5f, 0.0f, -1.0f),//right side

		glm::vec3(-0.5f, 0.0f, -1.0f),//left side
		glm::vec3(0.0f, 0.5f, -1.0f)//top

	};

	//Plane positions for bookOne
	glm::vec3 planePositionsBookOne[] =
	{
		glm::vec3(-4.5f, -0.25f, 1.5f),//front
		glm::vec3(-4.5f, -0.25f, -1.5f),//back
		glm::vec3(-2.5f, -0.25f, 0.0f),//right

		glm::vec3(-6.5f, -0.25f, 0.0f)//left


	};

	//Plane positions for bookTwo
	glm::vec3 planePositionsBookTwo[] =
	{
		glm::vec3(-4.5f, 0.25f, 1.5f),//front
		glm::vec3(-4.5f, 0.25f, -1.5f),//back
		glm::vec3(-2.5f, 0.25f, 0.0f),//right

		glm::vec3(-6.5f, 0.25f, 0.0f),//left
		glm::vec3(-4.5f, 0.5f, 0.0f)//top


	};

	//Plane positions for hardDrive
	glm::vec3 planePositionsHardDrive[] =
	{
		glm::vec3(0.0f, -0.38f, 0.5f),//front
		glm::vec3(0.0f, -0.38f, 2.0f),//back
		glm::vec3(1.f, -0.38f, 1.25f),//right side

		glm::vec3(-1.f, -0.38f, 1.25f),//left side
		glm::vec3(0.0f, -0.25f, 1.25f)//top


	};


	//Plane positions for speaker
	glm::vec3 planePositionsSpeaker[] =
	{
		glm::vec3(4.5f, 0.0f, -0.5f),//front
		glm::vec3(4.5f, 0.0f, -1.5f),//back

		glm::vec3(3.f, 0.0f, -1.0f),//right side
		glm::vec3(6.f, 0.0f, -1.0f),//left side
		glm::vec3(4.5f, 0.5f, -1.0f)//top


	};


	//Plane rotations
	glm::float32 planeRotationsY[] = {
		0.f, 180.f, 90.f, -90.f, 0.f
	};

	glm::float32 planeRotationsX[] = {
		0.f, 0.f, 0.f, 0.f, -90.f
	};


	// Setup some OpenGL options
	glEnable(GL_DEPTH_TEST);

	// Wireframe mode
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	GLuint VBO, EBO, VAO, floorVBO, floorEBO, floorVAO, labelVBO, labelEBO, labelVAO,
		bookOneVBO, bookOneEBO, bookOneVAO, bookTwoVBO, bookTwoEBO, bookTwoVAO,
		lampVBO, lampEBO, lampVAO, hardDriveVBO, hardDriveEBO, hardDriveVAO,
		speakerVBO, speakerEBO, speakerVAO;

	glGenBuffers(1, &VBO); // Create VBO
	glGenBuffers(1, &EBO); // Create EBO

	glGenBuffers(1, &floorVBO); // Create VBO
	glGenBuffers(1, &floorEBO); // Create EBO

	glGenBuffers(1, &labelVBO); // Create VBO
	glGenBuffers(1, &labelEBO); // Create EBO

	glGenBuffers(1, &bookOneVBO); // Create VBO
	glGenBuffers(1, &bookOneEBO); // Create EBO

	glGenBuffers(1, &bookTwoVBO); // Create VBO
	glGenBuffers(1, &bookTwoEBO); // Create EBO

	glGenBuffers(1, &lampVBO); // Create VBO
	glGenBuffers(1, &lampEBO); // Create EBO

	glGenBuffers(1, &hardDriveVBO); // Create VBO
	glGenBuffers(1, &hardDriveEBO); // Create EBO

	glGenBuffers(1, &speakerVBO); // Create VBO
	glGenBuffers(1, &speakerEBO); // Create EBO

	glGenVertexArrays(1, &VAO); // Create VOA
	glGenVertexArrays(1, &floorVAO); // Create VOA
	glGenVertexArrays(1, &labelVAO); // Create VOA
	glGenVertexArrays(1, &bookOneVAO);
	glGenVertexArrays(1, &bookTwoVAO);
	glGenVertexArrays(1, &lampVAO);
	glGenVertexArrays(1, &hardDriveVAO);
	glGenVertexArrays(1, &speakerVAO);

	//cube
	glBindVertexArray(VAO);

	// VBO and EBO Placed in User-Defined VAO
	glBindBuffer(GL_ARRAY_BUFFER, VBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO); // Select EBO


	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

																					 // Specify attribute location and layout to GPU
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);//change 6 to 8
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);//new attrib pointer for texture coordinates

	glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

	//floor
	glBindVertexArray(floorVAO);

	glBindBuffer(GL_ARRAY_BUFFER, floorVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, floorEBO); // Select EBO

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);//change 6 to 8
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);//new attrib pointer for texture coordinates

	glBindVertexArray(0);

	//label
	glBindVertexArray(labelVAO);

	glBindBuffer(GL_ARRAY_BUFFER, labelVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, labelEBO); // Select EBO

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);//change 6 to 8
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);//new attrib pointer for texture coordinates

	glBindVertexArray(0);

	//bookOne
	glBindVertexArray(bookOneVAO);

	glBindBuffer(GL_ARRAY_BUFFER, bookOneVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bookOneEBO); // Select EBO

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);//change 6 to 8
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);//new attrib pointer for texture coordinates

	glBindVertexArray(0);

	//bookTwo
	glBindVertexArray(bookTwoVAO);

	glBindBuffer(GL_ARRAY_BUFFER, bookTwoVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bookTwoEBO); // Select EBO

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);//change 6 to 8
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);//new attrib pointer for texture coordinates

	glBindVertexArray(0);

	//hardDrive
	glBindVertexArray(hardDriveVAO);

	glBindBuffer(GL_ARRAY_BUFFER, hardDriveVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, hardDriveEBO); // Select EBO

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);//change 6 to 8
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);//new attrib pointer for texture coordinates

	glBindVertexArray(0);

	//speaker
	glBindVertexArray(speakerVAO);

	glBindBuffer(GL_ARRAY_BUFFER, speakerVBO); // Select VBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, speakerEBO); // Select EBO

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Load vertex attributes
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);//change 6 to 8
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
	glEnableVertexAttribArray(3);//new attrib pointer for texture coordinates

	glBindVertexArray(0);


	//lamp
	glBindVertexArray(lampVAO);

		glBindBuffer(GL_ARRAY_BUFFER, lampVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lampEBO); // Select EBO
		glBufferData(GL_ARRAY_BUFFER, sizeof(lampVertices), lampVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);
	glBindVertexArray(0);


	//Load Textures
	int crateTexWidth, crateTexHeight, gridTexWidth, gridTexHeight, labelTexWidth, labelTexHeight,
		bookTwoTexWidth, bookTwoTexHeight, bookOneTexWidth, bookOneTexHeight, hardDriveTexWidth, hardDriveTexHeight,
		speakerTexWidth, speakerTexHeight;
	unsigned char* crateImage = SOIL_load_image("kt.png", &crateTexWidth, &crateTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* gridImage = SOIL_load_image("table.png", &gridTexWidth, &gridTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* labelImage = SOIL_load_image("Tape.png", &labelTexWidth, &labelTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* bookOneImage = SOIL_load_image("bookOne.png", &bookOneTexWidth, &bookOneTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* bookTwoImage = SOIL_load_image("bookTwo.png", &bookTwoTexWidth, &bookTwoTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* hardDriveImage = SOIL_load_image("hardDrive.png", &hardDriveTexWidth, &hardDriveTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* speakerImage = SOIL_load_image("speaker.png", &speakerTexWidth, &speakerTexHeight, 0, SOIL_LOAD_RGB);

	//Generate Textures
	GLuint crateTexture;
	glGenTextures(1, &crateTexture);
	glBindTexture(GL_TEXTURE_2D, crateTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, crateTexWidth, crateTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, crateImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(crateImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	//Texture for floor
	GLuint gridTexture;
	glGenTextures(1, &gridTexture);
	glBindTexture(GL_TEXTURE_2D, gridTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, gridTexWidth, gridTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, gridImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(gridImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	//Texture for label
	GLuint labelTexture;
	glGenTextures(1, &labelTexture);
	glBindTexture(GL_TEXTURE_2D, labelTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, labelTexWidth, labelTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, labelImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(labelImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	//Texture for bookOne
	GLuint bookOneTexture;
	glGenTextures(1, &bookOneTexture);
	glBindTexture(GL_TEXTURE_2D, bookOneTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, bookOneTexWidth, bookOneTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, bookOneImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(bookOneImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	//Texture for bookTwo
	GLuint bookTwoTexture;
	glGenTextures(1, &bookTwoTexture);
	glBindTexture(GL_TEXTURE_2D, bookTwoTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, bookTwoTexWidth, bookTwoTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, bookTwoImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(bookTwoImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	//Texture for hardDrive
	GLuint hardDriveTexture;
	glGenTextures(1, &hardDriveTexture);
	glBindTexture(GL_TEXTURE_2D, hardDriveTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, hardDriveTexWidth, hardDriveTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, hardDriveImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(hardDriveImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	//Texture for speaker
	GLuint speakerTexture;
	glGenTextures(1, &speakerTexture);
	glBindTexture(GL_TEXTURE_2D, speakerTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, speakerTexWidth, speakerTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, speakerImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(speakerImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	// Vertex shader source code
	string vertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;" //change to vec3
		"layout(location = 1) in vec3 aColor;" //change to vec3
		"layout(location = 2) in vec2 texCoord;"//add for texcoord
		"layout(location = 3) in vec3 normal;"
		"out vec3 oColor;"//change to vec3
		"out vec2 oTexCoord;"//add for texcoord
		"out vec3 oNormal;"
		"out vec3 FragPos;"
		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"
		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		"oColor = aColor;"
		"oTexCoord = texCoord;"//add for texcoord
		"oNormal = mat3(transpose(inverse(model))) * normal;"
		"FragPos = vec3(model * vec4(vPosition, 1.0f));"
		"}\n";

	// Fragment shader source code
	string fragmentShaderSource =
		"#version 330 core\n"
		"in vec3 oColor;"
		"in vec2 oTexCoord;"//add for texcoord
		"in vec3 oNormal;"
		"in vec3 FragPos;"
		"out vec4 fragColor;"
		"uniform sampler2D myTexture;"
		"uniform vec3 objectColor;"
		"uniform vec3 lightColor;"
		"uniform vec3 lightPos;"
		"uniform vec3 viewPos;"
		"void main()\n"
		"{\n"
		"//Ambient\n"
		"float ambientStrength = 0.3f;"
		"vec3 ambient = ambientStrength * lightColor;"
		"//Diffuse\n"
		"vec3 norm = normalize(oNormal);"
		"vec3 lightDir = normalize(lightPos - FragPos);"
		"float diff = max(dot(norm, lightDir), 0.0);"
		"vec3 diffuse = diff * lightColor;"
		"//Specularity\n"
		"float specularStrength = 1.5f;"
		"vec3 viewDir = normalize(viewPos - FragPos);"
		"vec3 reflectDir = reflect(-lightDir, norm);"
		"float spec = pow(max(dot(viewDir, reflectDir), 0.0), 128);"
		"vec3 specular = specularStrength * spec * lightColor;"
		"vec3 result = (ambient + diffuse + specular) * objectColor;"
		"fragColor = texture(myTexture, oTexCoord) * vec4(result, 1.0f);"//lighting
		"}\n";

	// Lamp vertex shader source code
	string lampVertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;" //change to vec3
		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"
		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		"}\n";

	// Lamp fragment shader source code
	string lampFragmentShaderSource =
		"#version 330 core\n"
		"out vec4 fragColor;"
		"void main()\n"
		"{\n"
		"fragColor = vec4(1.0f);"//lighting
		"}\n";

	// Creating Shader Program
	GLuint shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);
	GLuint lampShaderProgram = CreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource);


	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		//Set deltaTime
		GLfloat currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// Resize window and graphics simultaneously
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);
		/* Render here */
		glEnable(GL_DEPTH_TEST);

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Use Shader Program exe and select VAO before drawing 
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes



		// Declare transformations (can be initialized outside loop)		

		glm::mat4 projectionMatrix;
		glm::mat4 viewMatrix;


		viewMatrix = glm::lookAt(cameraPosition, getTarget(), worldUp);

		if (viewProjection) {
			projectionMatrix = glm::perspective(fov, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
		}
		else {

			projectionMatrix = glm::ortho(-20.0f, 20.0f, -20.0f, 20.0f, 0.1f, 100.0f);
		}



		// Get matrix's uniform location and set matrix
		GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
		GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
		GLint projectionLoc = glGetUniformLocation(shaderProgram, "projection");

		//Get light and object color, and light position location
		GLint objectColorLoc = glGetUniformLocation(shaderProgram, "objectColor");
		GLint lightColorLoc = glGetUniformLocation(shaderProgram, "lightColor");
		GLint lightPosLoc = glGetUniformLocation(shaderProgram, "lightPos");
		GLint viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");

		//Assign light and object colors
		glUniform3f(objectColorLoc, 1.0f, 1.0f, 1.0f);
		glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);

		//Set light position
		glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);

		//Specify view position
		glUniform3f(viewPosLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

		//glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
		glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

		glBindTexture(GL_TEXTURE_2D, crateTexture);

		glBindVertexArray(VAO); // User-defined VAO must be called before draw. 

		for (GLuint i = 0; i < 5; i++)
		{
			glm::mat4 modelMatrix;

			modelMatrix = glm::translate(modelMatrix, planePositions[i]);

			modelMatrix = glm::rotate(modelMatrix, planeRotationsY[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

			if (i >= 5)

				modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			// Draw primitive(s)
			draw();
		}
		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after


		glBindTexture(GL_TEXTURE_2D, gridTexture);
		// Select and transform floor
		glBindVertexArray(floorVAO);
		glm::mat4 modelMatrix;
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0.f, -.5f, 0.f));
		modelMatrix = glm::rotate(modelMatrix, -90.f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(15.f, 7.f, 10.f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
		draw();
		glBindVertexArray(0); //Incase different VAO will be used after


		//Label object
		for (GLuint i = 0; i < 2; i++) {
		glBindTexture(GL_TEXTURE_2D, labelTexture);
		glBindVertexArray(labelVAO);
		glm::mat4 modelMatrix;
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, 1.0f, -1.5f));
		modelMatrix = glm::rotate(modelMatrix, 180.f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));

		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
		draw();
	}
		glBindVertexArray(0);


		glBindTexture(GL_TEXTURE_2D, bookOneTexture);

		glBindVertexArray(bookOneVAO); // User-defined VAO must be called before draw. 

		for (GLuint i = 0; i < 4; i++)
		{
			glm::mat4 modelMatrix;
			
			modelMatrix = glm::translate(modelMatrix, planePositionsBookOne[i]);
			modelMatrix = glm::rotate(modelMatrix, planeRotationsY[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 0.5f, 2.f));
			
			if(i < 2)
				modelMatrix = glm::scale(modelMatrix, glm::vec3(1.3325f, 1.0f, 1.0f));

			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			// Draw primitive(s)
			draw();
		}
		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after
		
		glBindTexture(GL_TEXTURE_2D, bookTwoTexture);

		glBindVertexArray(bookTwoVAO); // User-defined VAO must be called before draw. 

		for (GLuint i = 0; i < 4; i++)
		{
			glm::mat4 modelMatrix;

			modelMatrix = glm::translate(modelMatrix, planePositionsBookTwo[i]);
			modelMatrix = glm::rotate(modelMatrix, planeRotationsY[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 0.5f, 2.f));

			if (i < 2)
				modelMatrix = glm::scale(modelMatrix, glm::vec3(1.3325f, 1.0f, 1.0f));


			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			// Draw primitive(s)
			draw();
		}
		for (GLuint i = 0; i < 5; i++)
		{
			glm::mat4 modelMatrix;
			if (i = 4)
				modelMatrix = glm::translate(modelMatrix, planePositionsBookTwo[i]);
				modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 0.5f, 3.f));
				modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(1.3325f, 1.0f, 1.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			draw();
		}
		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after


		glBindTexture(GL_TEXTURE_2D, hardDriveTexture);

		glBindVertexArray(hardDriveVAO); // User-defined VAO must be called before draw. 

		for (GLuint i = 0; i < 4; i++)
		{
			glm::mat4 modelMatrix;

			modelMatrix = glm::translate(modelMatrix, planePositionsHardDrive[i]);

			modelMatrix = glm::rotate(modelMatrix, planeRotationsY[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(2.0f, .25f, 1.f));
			if (i > 1)
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.75f, 1.f, 1.));
			

			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			// Draw primitive(s)
			draw();
		}
		for (GLuint i = 0; i < 5; i++)
		{
			glm::mat4 modelMatrix;
			if (i = 4)
				modelMatrix = glm::translate(modelMatrix, planePositionsHardDrive[i]);
				modelMatrix = glm::scale(modelMatrix, glm::vec3(2.f, 0.5f, 1.5f));
				modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			draw();
		}
		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glBindTexture(GL_TEXTURE_2D, speakerTexture);

		glBindVertexArray(speakerVAO); // User-defined VAO must be called before draw. 

		for (GLuint i = 0; i < 5; i++)
		{
			glm::mat4 modelMatrix;

			modelMatrix = glm::translate(modelMatrix, planePositionsSpeaker[i]);

			modelMatrix = glm::rotate(modelMatrix, planeRotationsY[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

			if (i < 2)
				modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 1.f, 1.f));
			if (i > 3)
				modelMatrix = glm::scale(modelMatrix, glm::vec3(3.f, 1.f, 1.f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			// Draw primitive(s)
			draw();
		}
		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after

		glUseProgram(0); // Incase different shader will be used after

		glUseProgram(lampShaderProgram);
		// Get matrix's uniform location and set matrix
		GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
		GLint lamViewLoc = glGetUniformLocation(lampShaderProgram, "view");
		GLint lampProjectionLoc = glGetUniformLocation(lampShaderProgram, "projection");
		glUniformMatrix4fv(lamViewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
		glUniformMatrix4fv(lampProjectionLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

		glBindVertexArray(lampVAO); // User-defined VAO must be called before draw. 

		for (GLuint i = 0; i < 5; i++)
		{
			glm::mat4 modelMatrix;

			modelMatrix = glm::translate(modelMatrix, planePositions[i] / glm::vec3(8., 8., 8.) + lightPosition);

			modelMatrix = glm::rotate(modelMatrix, planeRotationsY[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

			if (i >= 5)

				modelMatrix = glm::rotate(modelMatrix, planeRotationsX[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::scale(modelMatrix, glm::vec3(.125f, .125f, .125f));
			glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

			// Draw primitive(s)
			draw();
		}
		// Unbind Shader exe and VOA after drawing per frame
		glBindVertexArray(0); //Incase different VAO wii be used after
		glUseProgram(0);

		/* Swap front and back buffers */
		glfwSwapBuffers(window);

		/* Poll for and process events */
		glfwPollEvents();

		//Poll camera transformations
		TransformCamera();

	}

	//Clear GPU resources
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);
	glDeleteBuffers(1, &EBO);
	glDeleteVertexArrays(1, &floorVAO);
	glDeleteBuffers(1, &floorVBO);
	glDeleteBuffers(1, &floorEBO);
	glDeleteVertexArrays(1, &labelVAO);
	glDeleteBuffers(1, &labelVBO);
	glDeleteBuffers(1, &labelEBO);
	glDeleteVertexArrays(1, &bookOneVAO);
	glDeleteBuffers(1, &bookOneVBO);
	glDeleteBuffers(1, &bookOneEBO);
	glDeleteVertexArrays(1, &bookTwoVAO);
	glDeleteBuffers(1, &bookTwoVBO);
	glDeleteBuffers(1, &bookTwoEBO);
	glDeleteVertexArrays(1, &hardDriveVAO);
	glDeleteBuffers(1, &hardDriveVBO);
	glDeleteBuffers(1, &hardDriveEBO);

	glfwTerminate();
	return 0;
}
//Define Input callback functions
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	//Display ASCII Keycode
	//cout << "ASCII: " << key << endl;

	if (action == GLFW_PRESS)
		keys[key] = true;
	else if (action == GLFW_RELEASE)
		keys[key] = false;

	static const float cameraSpeed = 5.5f;
	float cameraOffset = cameraSpeed * deltaTime;

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPosition += cameraOffset * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPosition -= cameraOffset * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPosition -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraOffset;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPosition += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraOffset;

	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		cameraPosition += cameraOffset * cameraUp;
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		cameraPosition -= cameraOffset * cameraUp;

	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
		viewProjection = !viewProjection;
}
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
	//Display scroll offset
	const float sensitivity = 0.1f;
	xChange *= sensitivity;
	yChange *= sensitivity;

	GLfloat cameraSpeed = xChange * deltaTime;
	cameraPosition += cameraSpeed * cameraRight;

	cameraSpeed = yChange * deltaTime;
	cameraPosition += cameraSpeed * cameraUp;

	if (yoffset > 0 && sensitivity < 0.1f)
		cameraSpeed += 0.01f;
	//cout << "Mouse sensitivity = " << cameraSpeed;
	if (yoffset < 0 && sensitivity > 0.01f)
		cameraSpeed += 0.01f;
	//cout << "Mouse sensitivity = " << cameraSpeed;


	//Scroll zoom functionality
	//Scroll between 1 and 45
/*	if (fov >= 1.f && fov <= 45.f)
		fov -= yoffset * 0.01f;
	//Default FOV
	if (fov < 1.f)
		fov = 1.f;
	if (fov > 45.f)
		fov = 45.f;*/


}
void cursor_position_callback(GLFWwindow* window, double xpos, double ypos) {
	//cout << "Mouse X: " << xpos << endl;
	//cout << "Mouse Y: " << ypos << endl;

	if (firstMouseMove)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouseMove = false;
	}

	//Calculate cursor offset
	xChange = xpos - lastX;
	yChange = lastY - ypos;

	lastX = xpos;
	lastY = ypos;

	const float sensitivity = 0.1f;
	xChange *= sensitivity;
	yChange *= sensitivity;
	//Pan camera
	if (isPanning)
	{
		if (cameraPosition.z < 0.f)
			cameraFront.z = 1.f;
		else
			cameraFront.z = -1.f;


		GLfloat cameraSpeed = xChange * deltaTime;
		cameraPosition += cameraSpeed * cameraRight;

		cameraSpeed = yChange * deltaTime;
		cameraPosition += cameraSpeed * cameraUp;
	}

	//Orbit camera
	if (isOrbiting) {
		rawYaw += xChange;
		rawPitch += yChange;

		//Convert yaw and pitch to degrees
		degYaw = glm::radians(rawYaw);
		//degPitch = glm::radians(rawPitch);
		degPitch = glm::clamp(glm::radians(rawPitch), -glm::pi<float>() / 2.f + .1f, glm::pi<float>() / 2.f - .1f);

		//Azimuth Altitude Formula
		cameraPosition.x = target.x + radius * cosf(degPitch) * sinf(degYaw);
		cameraPosition.y = target.y + radius * sinf(degPitch);
		cameraPosition.z = target.z + radius * cosf(degPitch) * cosf(degYaw);

	}
}
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
	/*
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
		cout << "LMB Clicked" << endl;
	if (button == GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW_PRESS)
		cout << "MMB Clicked" << endl;
	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
		cout << "RMB Clicked" << endl;
		*/

	if (action == GLFW_PRESS)
		mouseButtons[button] = true;
	else if (action == GLFW_PRESS)
		mouseButtons[button] = false;
}

//Declare getTarget function
glm::vec3 getTarget() {
	if (isPanning)
		target = cameraPosition + cameraFront;

	return target;
}

//Define TransformCamera fucntion
void TransformCamera() {
	//Pan camera
	/*if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_MIDDLE])
		isPanning = true;
	else
		isPanning = false;*/

		//Orbit Camera
		//uses alt and click modifier because without it, mouse can interfere with key commands
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_LEFT])
		isOrbiting = true;
	else
		isOrbiting = false;

	//Reset camera
	if (keys[GLFW_KEY_F])
		initCamera();



}

void initCamera() {
	cameraPosition = glm::vec3(0.f, 0.f, 3.f);
	target = glm::vec3(0.f, 0.f, 0.f);
	cameraDirection = glm::normalize(cameraPosition - target);
	worldUp = glm::vec3(0.f, 1.f, 0.f);
	cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));
	cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight));
	cameraFront = glm::normalize(glm::vec3(0.f, 0.f, -1.f));
}
GLuint shaderProgram;




//Orthographic view
